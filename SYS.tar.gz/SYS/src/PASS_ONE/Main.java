package PASS_ONE;

import java.io.*;

public class Main {
	public static void main(String[] args) throws IOException{
		Initialize initialize = new Initialize();
		initialize.initializeOpcode();
		initialize.initializeRegister();
		Operation op = new Operation();
		op.makeIntermediateTable();
	}
}
