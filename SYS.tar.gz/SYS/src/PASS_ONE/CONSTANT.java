package PASS_ONE;

public class CONSTANT {
	public String INPUT_FILE = "input.txt";
	public String SYMBOL_TABLE = "symbol_table.txt";
	public String LITERAL_TABLE = "literal_table.txt";
	public String INTERMEDIATE_TABLE = "intermediate_table.txt";
}
