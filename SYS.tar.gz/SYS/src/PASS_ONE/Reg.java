package PASS_ONE;

public class Reg {
	private String Register;
	private Integer Code;
	
	public Reg(String Register, Integer Code){
		this.Register = Register;
		this.Code = Code;
	}

	public String getRegister() {
		return Register;
	}

	public void setRegister(String register) {
		Register = register;
	}

	public Integer getCode() {
		return Code;
	}

	public void setCode(Integer code) {
		Code = code;
	}
	

}
