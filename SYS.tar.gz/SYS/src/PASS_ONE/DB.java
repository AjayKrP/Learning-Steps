package PASS_ONE;

public class DB {
	private String Mnemonic;
	private String Opcode;
	private Integer Length;
	private String Class;
	
	public DB(String Mnemonic, String Class, String Opcode, Integer Length ){
		this.Mnemonic = Mnemonic;
		this.Class = Class;
		this.Opcode = Opcode;
		this.Length = Length;
	}

	public String getMnemonic() {
		return Mnemonic;
	}

	public void setMnemonic(String mnemonic) {
		Mnemonic = mnemonic;
	}

	public String getOpcode() {
		return Opcode;
	}

	public void setOpcode(String opcode) {
		Opcode = opcode;
	}

	public Integer getLength() {
		return Length;
	}

	public void setLength(Integer length) {
		Length = length;
	}

	public String getClass1() {
		return Class;
	}

	public void setClass(String class1) {
		Class = class1;
	}
	
	
}
