package PASS_ONE;

import java.util.*;

public class Initialize {
	public ArrayList<DB> Opcode;
	public ArrayList<Reg>RegType;
	public Initialize(){
		Opcode = new ArrayList<DB>();
		RegType = new ArrayList<Reg>();
	}
	public void initializeOpcode(){
		Opcode.add(new DB("START", "AD", "00", 1));
		Opcode.add(new DB("ADD", "IS", "01", 1));
		Opcode.add(new DB("STOP", "AD", "03", 1));
		Opcode.add(new DB("MOVER", "IS", "04", 1));
		Opcode.add(new DB("MOVEM", "IS", "05", 1));
	}
	
	public ArrayList<DB> getOpcode() {
		return Opcode;
	}
	public void setOpcode(ArrayList<DB> opcode) {
		Opcode = opcode;
	}
	public ArrayList<Reg> getRegType() {
		return RegType;
	}
	public void setRegType(ArrayList<Reg> regType) {
		RegType = regType;
	}
	public void initializeRegister(){
		RegType.add(new Reg("AREG", 1));
		RegType.add(new Reg("BREG", 2));
		RegType.add(new Reg("CREG", 3));
	}
}
