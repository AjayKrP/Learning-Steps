package PASS_ONE;

import java.util.*;
import java.io.*;

public class Tokenize {
	public ArrayList<String[]> token;
	public CONSTANT constant;
	public Tokenize(){
		token = new ArrayList<String[]>();
	}
	
	public void tokenizeFile(){
		FileReader in = null;
		try {
			in = new FileReader("/home/student/input.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader bf = new BufferedReader(in);
		
		int c;
		try {
			while((c = bf.read()) != -1){
				String[] str = bf.readLine().split(" ");
				token.add(str);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
