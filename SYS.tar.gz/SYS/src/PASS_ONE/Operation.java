package PASS_ONE;

import java.util.*;

public class Operation {
	public Tokenize tokenize;
	private DB db;
	private Reg reg;
	public Initialize init;
	public ArrayList<String[]> intermediateCode;
	public static ArrayList<String[]>literalTable;
	public static ArrayList<String[]>symbolTable;
	public static int count = 1;
	public Operation(){
		tokenize = new Tokenize();
		init = new Initialize();
		literalTable = new ArrayList<String[]>();
		symbolTable = new ArrayList<String[]>();
	}
	
	public void PrintOutput(){
		System.out.println("Intermediate Table");
		tokenize.tokenizeFile();
		for(int i = 0; i < tokenize.token.size(); ++i){
			String[] str = tokenize.token.get(i);
			for(int j = 0; j < str.length; ++j){
				System.out.print(str[j] + " ");
			}
			System.out.println();
		}
	}
	
	
	public void makeTable(){
		tokenize.tokenizeFile();
		for(int i = 0; i < tokenize.token.size(); ++i){
			String[] str = tokenize.token.get(i);
			for(int j = 0; j < str.length; ++j){
				
			}
		}
	}
	
	public static void makeLiteralTable(String Literal, Integer Address){
		String [] str = {Literal, String.valueOf(Address + count++)};
		literalTable.add(str);
	}
	
	public static void makeSymbolTable(String Symbol, Integer Address, Integer length){
		String[] str = {Symbol, String.valueOf(Address + count++), String.valueOf(length)};
		symbolTable.add(str);
	}
	
	public static void printLiteralTable(){
		System.out.println("Literal Table");
		for(int i = 0; i < literalTable.size(); ++i){
			String[] str = literalTable.get(i);
			System.out.println(str[0] +"\t"+str[1]);
		}
		System.out.println();
	}
	
	public static void printSymbolTable(){
		System.out.println("Symbol Table");
		for(int i = 0; i < symbolTable.size(); ++i){
			String[] str = symbolTable.get(i);
				System.out.println(str[0] +"\t"+str[1]+"\t"+str[2]);
		}
		System.out.println();
	}
	
	public static Integer getCode(String reg){
		if(reg.equals("AREG")){
			return 1;
		}
		else if(reg.equals("BREG")){
			return 2;
		}
		else if(reg.equals("CREG")){
			return 3;
		}
		return null;
	}
	
	public static char getType(char str){
		if(str == '='){
			return 'L';
		}
		else{
			return 'S';
		}

	}
	
	
	
	@SuppressWarnings("null")
	public void makeIntermediateTable(){
		System.out.println("Intermediate Table");
		init.initializeOpcode();
		init.initializeRegister();
		tokenize.tokenizeFile();
		int address = 0;
		for(int i = 0; i < tokenize.token.size(); ++i){
			String[] str = tokenize.token.get(i);
			
			if(str[0].equals("START")){
				System.out.println("(AD, 00) (C,"+(String)str[1]+")");
				address = Integer.parseInt(str[1]);
			}
			else{
				ArrayList<?> arr = init.Opcode;
				for(int ii = 0; ii < arr.size(); ++ii){
					DB db = (DB) arr.get(ii); 
					if(db.getMnemonic().equals(str[0])){
						System.out.println("("+db.getClass1()+" "+  db.getOpcode()+")"+" "+"("+getCode(str[1])+")"+"("+getType(str[2].charAt(0))+", 01 )");
						if(str[2].charAt(0) == '='){
							makeLiteralTable(str[2], address);
						}
						else{
						   makeSymbolTable(str[2], address, 1);
						}
	
					}
				}
				
			}
		}
		
		printLiteralTable();
		printSymbolTable();
	}

}
